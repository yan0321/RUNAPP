# My Web App

📄 אפליקציית WEB בסיסית להרצה עם Flask ב‑Codex.

## 📦 הפעלה מקומית:
```bash
pip install -r requirements.txt
python app.py
```
ואז גש ל‑http://localhost:8080
